print('안녕하세요.')
print('홍길동입니다.')
