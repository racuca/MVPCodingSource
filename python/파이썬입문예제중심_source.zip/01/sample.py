kor = 90
eng = 100

sum = kor + eng
avg = sum/2

print('합계 : ', sum)
print('평균 : ', avg) 
