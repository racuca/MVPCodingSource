print(True) if 0 else print(False)
print(True) if None else print(False)
print(True) if 15 else print(False)
print(True) if '홍길동' else print(False)