name = input('이름을 입력하세요 : ')

if not name :
    print('이름이 입력되지 않았다.')
else :
    print('이름 : %s' % name)