num = int(input('숫자를 입력하세요 : '))

if num % 2 == 0 :
    print('짝수이다.')
else :
    print('홀수이다.')