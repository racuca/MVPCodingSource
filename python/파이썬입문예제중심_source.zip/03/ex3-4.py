score1 = int(input('필기성적을 입력하세요 : '))
score2 = int(input('실기성적을 입력하세요 : '))

if score1 >= 80 and score2 >= 80 :
    print('합격!')
else :
    print('불합격!')