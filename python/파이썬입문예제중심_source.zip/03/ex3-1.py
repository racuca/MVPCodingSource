x = int(input('숫자를 입력하세요 : '))

if x > 0 :
    print('양수!')
else :
    print('0 또는 음수!')