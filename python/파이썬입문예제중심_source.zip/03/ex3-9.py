answer = '12345'
password = input('비밀번호를 입력하세요 : ')

if password == answer :
    print('비밀번호 OK!')
else :
    print('비밀번호 Not OK!')