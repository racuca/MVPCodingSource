a = input('좌석 종류를 입력해 주세요(1:일반실, 2:특실) : ')

seat1 = '일반실'
seat2 = '특실'

if a == '1' :
    print('%s입니다.' % seat1)

if a == '2' :
    print('%s입니다.' % seat2)