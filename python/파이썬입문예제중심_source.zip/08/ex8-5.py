import math as m

print('sin(pi/2) : %.2f' % m.sin(m.pi/2))
print('cos(pi) : %.2f' % m.cos(m.pi))
print('tan(pi*2) : %.2f' % m.tan(m.pi*2))

print('2의 4승 : %d' % m.pow(2,4))
print('49의 제곱근 : %d' % m.sqrt(49))
print('log10(100) : %.2f' % m.log10(100))
