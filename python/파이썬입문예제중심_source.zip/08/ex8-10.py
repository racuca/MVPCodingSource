import random

fruits = ['사과', '바나나', '오렌지']

for i in range(3) :
    random.shuffle(fruits)
    print(fruits)