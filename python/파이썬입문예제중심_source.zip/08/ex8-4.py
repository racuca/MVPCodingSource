import math

print('floor(7.7) : %d' % math.floor(7.7))
print('ceil(10.1) : %d' % math.ceil(10.1))
print('round(8.6) : %d' % round(8.6))
print('5의 펙토리알 : %d' % math.factorial(5))
