import random

toss = ['가위', '바위', '보']

for i in range(5) :
    print(random.choice(toss))