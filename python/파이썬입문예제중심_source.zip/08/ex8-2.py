import greet

print(greet.hello1('안지수'))
print(greet.hello2('홍지영'))
print(greet.hello3('황예림'))