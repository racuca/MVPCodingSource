def hello1(name) : 
    x = '%s님 안녕하세요.' % name
    return x

def hello2(name) : 
    x = '%s님 반갑습니다.' % name
    return x
    
def hello3(name) : 
    x = '%s님 만나서 반가워요.' % name
    return x