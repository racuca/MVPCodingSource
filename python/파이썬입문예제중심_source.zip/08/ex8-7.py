import random

for i in range(5) :
    print(random.randrange(1, 11, 2))