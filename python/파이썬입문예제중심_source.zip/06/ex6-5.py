phones = {'갤럭시 노트8': 2017,  '갤럭시 S9': 2018, '갤럭시 노트10': 2019, '갤럭시 S20': 2020}
print(phones)

for key in phones :
    print('%s => %s' % (key, phones[key]))

print(len(phones))