menu = ('coffee', 'milk', 'tea', 'cider')

print(menu)
print(menu[0])
print(menu[2])
print(menu[0:3])

menu[1] = 'cola'