members = {'name':'안지영', 'age':30, 'email':'jiyoung@korea.com'}

print(members)
print(members['name'])
print(members['age'])

print('길이 : %d' % len(members))