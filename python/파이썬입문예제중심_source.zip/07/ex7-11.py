def func() :
    print(x)
    print(id(x))
    
x = 10
print(x)
print(id(x))
func()