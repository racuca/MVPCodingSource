def func() :
    x = 10
    print(x)

func()
print(x)