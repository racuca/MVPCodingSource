file = open('sample.txt', 'w', encoding='utf8')
file.write('안녕하세요. 반갑습니다.')
file.close()
print('파일 쓰기 완료!')
