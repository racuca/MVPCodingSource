def even_odd(num) :
    if num % 2 == 0 :
        print('%d은(는) 짝수이다.' % num)
    else :
        print('%d은(는) 홀수이다.' % num)

even_odd(7)
even_odd(16)