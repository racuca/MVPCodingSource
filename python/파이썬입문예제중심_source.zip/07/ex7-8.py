x = lambda a : a**2

print(x(5))
print(x(10))