eng score = 90
7font = '굴림'
my-age = 20
percent% = 100
animal# = '사슴'