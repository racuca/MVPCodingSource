year = 2020
month = 3
day = 5

print(year, month, day, sep='/')