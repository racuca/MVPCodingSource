eng = 80
result = '영어 점수 : ' + str(eng) + '점'
print(result)