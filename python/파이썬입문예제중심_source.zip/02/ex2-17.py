name = '홍지수'
greet = name + '님 안녕하세요!'
print(greet)