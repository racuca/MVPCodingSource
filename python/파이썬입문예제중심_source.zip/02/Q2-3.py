x = 20
y = 4

x = y % x
print(x)

y -= x * 3
print(x, y)