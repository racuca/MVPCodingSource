name = "홍길동"
age = 30
height = 171.5

print('성 :', name[0])
print('이름 :', name[1:])
print("%s의 나이 : %d세, 키 : %.2fcm" % (name, age, height))