score1 = 80
score2 = 87

sum = score1 + score2
avg = sum/2

print('두 과목 점수 : %d, %d' % (score1, score2))
print('합계 : %d, 평균 : %.2f' % (sum, avg))