x = 2**3
print(x)

y = 10**4
print(y)