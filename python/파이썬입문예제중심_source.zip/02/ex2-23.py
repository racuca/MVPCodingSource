height = 172.5
a = '키는 %.2f입니다.' % height

print(a)