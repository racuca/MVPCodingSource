width  = 10
height = 3

area = width * height / 2

print('삼각형의 밑변 길이 :', width)
print('삼각형의 높이 :', height)
print('삼각형의 면적 :', area)