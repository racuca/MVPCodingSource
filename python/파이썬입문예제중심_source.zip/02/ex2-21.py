age = 20
a = '나이는 %d살 입니다.' % age
print(a)