x = 10
x += 20            # x = x + 20 과  동일
print(x)