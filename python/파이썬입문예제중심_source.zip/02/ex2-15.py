hello = '안녕' * 5

print(hello)