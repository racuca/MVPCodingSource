a = 30
print(a)
print(type(a))

b = '30'
print(b)
print(type(b))