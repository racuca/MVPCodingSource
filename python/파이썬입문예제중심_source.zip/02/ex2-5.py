x = 3.3764
y = 6/2
print(x, y)
print(type(x), type(y))