x = 'I am happy!'

print(x)
print(x[0])
print(x[0:3])
print(x[5:])
print(x[-1])
print(x[-3:])
print(x[-4:-2])