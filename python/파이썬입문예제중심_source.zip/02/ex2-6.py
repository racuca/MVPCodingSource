a = 'x'
b = 'I am ok.'
c = "안녕하세요."

print(a)
print(b)
print(c)
print(type(c))