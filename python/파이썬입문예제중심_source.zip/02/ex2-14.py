x = 3
y = 5
x *= x + y        # x = x * (x + y)와 동일
print(x)