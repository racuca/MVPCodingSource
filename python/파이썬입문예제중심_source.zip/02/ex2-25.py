name = '홍길동'
age = 30
height = 173.7
print(name, age, height)