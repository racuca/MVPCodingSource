x = 10 % 3
print(x)
 
y = 7//3
print(y)