a = True
b = False
print(a)
print(b)

c = 10 > 20
print(c)

print(type(a))