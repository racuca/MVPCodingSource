a = '안녕하세요.'
b = '반갑습니다.'

print(a)
print(b)

print('\n\n')

print(a, end='')
print(b)