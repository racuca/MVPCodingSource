x = 20
Computer = 'Mac'
Age = 30
my_score = 70
_name = '홍길동'
myBirthYear = 1997
data2 = 20.3

print(x, Computer, Age, my_score, _name, myBirthYear, data2)