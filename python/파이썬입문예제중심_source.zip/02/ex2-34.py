inch = float(input('인치(inch)를 입력하세요 : '))

cm = inch * 2.54

print('센티미터 : %.2f' % cm)