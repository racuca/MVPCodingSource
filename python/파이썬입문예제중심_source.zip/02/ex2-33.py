a = input('첫 번째 숫자를 입력하세요 : ')
b = input('두 번째 숫자를 입력하세요 : ')

c = int(a) + int(b)

print(c)