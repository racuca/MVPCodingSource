x = 30
print(x)
print(type(x))