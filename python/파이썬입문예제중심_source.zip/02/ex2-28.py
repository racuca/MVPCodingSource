name = '김소원'
id = 'kim'
point = 18000

print('이름 : {}'.format(name))
print('아이디: {}, 마일리지 : {}'.format(id, point))