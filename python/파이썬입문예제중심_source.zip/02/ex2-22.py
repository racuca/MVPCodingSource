year = 2020
month = 3
day = 5

a = '%d-%02d-%02d' % (year, month, day)
print(a)