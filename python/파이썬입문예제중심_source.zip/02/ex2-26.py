x = 10
y = 20

print('x = ' + str(x) + ', y = ' + str(y))