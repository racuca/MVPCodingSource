name = '황예린'
age = 18
eyesight = 1.2

a = '이름 : {}'.format(name)
b = '나이 : {}세'.format(age)
c = '시력 : {}'.format(eyesight)

print(a)
print(b)
print(c)