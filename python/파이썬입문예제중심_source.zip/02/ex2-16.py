a = '쥐 구멍에 볕 들 날 있다.'

b = len(a)

print(b)