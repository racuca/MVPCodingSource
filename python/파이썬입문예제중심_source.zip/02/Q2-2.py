price = 800
buy = 3
pay = 5000

change = pay - price * buy

print('물건가격 :', price, '원')
print('구매개수 :', buy, '개')
print('지불금액 :', pay, '원')
print('거스름돈 :', change, '원')