name = '김수영'
a = '나는 %s입니다.' % name
print(a)