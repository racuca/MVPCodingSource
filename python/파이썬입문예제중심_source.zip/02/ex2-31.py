name = input('이름을 입력하세요 : ')

print('%s님 반갑습니다.' % name)