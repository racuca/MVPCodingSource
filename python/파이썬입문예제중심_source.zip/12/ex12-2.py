import matplotlib.pyplot as plt

plt.plot(['kim', 'lee', 'kang'], [85, 88, 90])

plt.title('English Score of three students')
plt.xlabel('Student Name ')
plt.ylabel('Score')

plt.show()