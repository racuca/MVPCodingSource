import matplotlib.pyplot as plt

data = [20, 30, 40]
x = [1, 2, 3]
plt.plot(x, data)
plt.show()