for x in range(5) :
    print('안녕하세요.')