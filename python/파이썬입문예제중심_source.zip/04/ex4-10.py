sum = 0
i = 1

while i <= 10 :
    sum += i
    print('i의 값 : %d => 합계 : %d' % (i, sum))
    i += 1