word = input('영어 문장을 입력하세요 : ') 

for x in word : 
    print(x)