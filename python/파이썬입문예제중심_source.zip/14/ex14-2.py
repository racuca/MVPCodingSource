import pandas as pd

obj = pd.Series([8, -20, -3, 13, 2])

print(obj.values)
print(obj.index)

print(obj[2])