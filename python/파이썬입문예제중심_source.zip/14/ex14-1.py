import pandas as pd

obj = pd.Series([5, -4, 7, 0, 12])
print(obj)