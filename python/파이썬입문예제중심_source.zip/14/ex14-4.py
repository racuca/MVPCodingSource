import pandas as pd

obj = pd.Series([10, 20, 30, 40, 50])

print(obj * 10)

print(obj[obj > 25])