import numpy as np

a = np.array([[10, 7, -8, 2],
             [-2, 2, 8, 3], 
             [6, -8, -5, 3]])

b = a * 2
print(b)

c = a * a
print(c)

print(a > b)