import numpy as np

data = np.random.randn(2,3)
print(data)
print(data.shape)
print(data.dtype)