import numpy as np

data1 = np.ones(8)
print(data1)

data2 = np.ones((3, 4), dtype=np.int32)
print(data2)