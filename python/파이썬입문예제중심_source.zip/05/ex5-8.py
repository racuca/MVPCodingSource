animals = ['토끼', '거북이', '사자', '호랑이']

i = 0
while i < len(animals) :
    print(animals[i])

    i += 1 