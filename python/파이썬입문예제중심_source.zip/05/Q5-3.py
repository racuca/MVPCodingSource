mylist = ['사과', '바나나', '파인애플', '배']
mylist.append('키위')

for a in mylist:
    print(a)