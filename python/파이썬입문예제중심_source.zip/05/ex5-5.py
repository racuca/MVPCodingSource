list2 = [-7, 1, 5, 8, 3, 9, 11, 13]
list2.sort()
print(list2)

list2.sort(reverse=True)
print(list2)