list1 = ['a', 'bb', 'c', 'd','aaa', 'c', 'ddd', 'aaa',  'b', 'cc', 'd', 'aaa', ]
length = list1.count('aaa')

print(length)