mylist = ['사과', '바나나', '파인애플', '포도', '오렌지', '배']

mylist.remove('바나나')
print(mylist)