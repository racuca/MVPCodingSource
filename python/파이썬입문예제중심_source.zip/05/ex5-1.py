fruits = ['사과', '오렌지', '딸기', '포도', '감', '키위', '멜론', '수박']
list1 = [5, 10.2, '탁구', True, [4, 5, 6]]
numbers = list(range(1, 10, 2))

print(fruits)
print(list1)
print(numbers)

print()
print(fruits[0])
print(fruits[1:4])
print(fruits[2:])
print(fruits[-1])
print(fruits[-4:-2])
print(fruits[-3:])