person1 = ['kim', 24, 'kim@naver.com']
person2 = ['lee', 35, 'lee@hanmail.net']

person = person1 + person2
print(person)