numbers = [[10, 20, 30], [40, 50, 60]]

print(numbers[0])
print(numbers[1])

print(numbers[0][0])
print(numbers[0][1])
print(numbers[0][2])

print(numbers[1][0])
print(numbers[1][1])
print(numbers[1][2])