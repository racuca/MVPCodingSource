a = ['red', 'green', 'blue']
a.append('yellow')
print(a)

a.insert(1, 'black')
print(a)

b = ['purple', 'white']
a.extend(b)
print(a)

c = a + b
print(c)