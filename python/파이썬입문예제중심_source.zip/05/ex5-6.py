fruits = ['apple', 'orange', 'banana']

for fruit in fruits :
    print(fruit)