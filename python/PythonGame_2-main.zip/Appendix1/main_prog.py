import sub_prog
r = input("원의 반지름을 입력해 주십시오 ")
a = sub_prog.menseki(int(r))
print("반지름 {}인 원의 넓이는 {}입니다".format(r, a))
