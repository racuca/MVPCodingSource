def menseki(r):
    return (r*r*3.14)
