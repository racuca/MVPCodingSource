import random
r = random.randint(0, 999)
print("." * r + "," + "." * (1000 - r))
