import random
r = random.randint(0, 999)
print("고양이" * r + "야옹이" + "고양이" * (1000 - r))
