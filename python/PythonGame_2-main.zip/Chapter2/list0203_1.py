import math
d = 45  # 도
a = math.radians(d)  # 라디안으로 변환
s = math.sin(a)
c = math.cos(a)
t = math.tan(a)
print("sin " + str(s))
print("cos " + str(c))
print("tan " + str(t))
