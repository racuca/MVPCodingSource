firstName = "쉬무엘"
lastName = "포터"
fullName = firstName + " " + lastName

print("안녕하세요, 저는", fullName, "이며 프로그래머랍니다!")