firstName = input("성은 무엇인가요? ")
lastName = input("이름은 무엇인가요? ")
fullName = firstName + " " + lastName

print("안녕하세요, 제 이름은", fullName, "이며 프로그래머랍니다!")