firstName = "쉬무엘"
print("안녕하세요, 저는", firstName, "이며 프로그래머랍니다!")