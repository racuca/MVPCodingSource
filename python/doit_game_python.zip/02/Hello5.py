name = input("이름이 무엇인가요?")
print("안녕하세요,", name, "님. 만나서 반갑습니다!")