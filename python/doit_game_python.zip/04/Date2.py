# 라이브러리 불러오기
import datetime

# 오늘 날짜 가져오기
today = datetime.datetime.now()

# 오늘의 년, 월, 일 출력하기
print("지금은", today.year, "년입니다.")
print("지금은", today.month, "월입니다.")
print("지금은", today.day, "일니다.")