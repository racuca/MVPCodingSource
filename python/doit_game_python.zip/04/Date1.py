# 라이브러리 불러오기
import datetime

# 오늘 날짜 가져오기
today = datetime.datetime.now()

# 출력하기
print("지금은", today, "입니다.")
