# 리스트로 이루어진 리스트 만들기
options = [["P", "바위 더미를 조사한다"],
           ["S", "구조물에 접근한다"],
           ["B", "삐 소리가 나는 곳으로 간다"],
           ["R", "도망간다!"]]
           
# 출력 테스트
print(options)
print(len(options))
print(len(options[0]))
print(options[0])
print(options[1])
print(options[1][0])
print(options[1][1])
