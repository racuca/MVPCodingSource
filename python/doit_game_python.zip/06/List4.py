# 리스트 만들기
animals = ["개", "개미", "고양이", "박쥐", "장어"]
# 요소의 개수 묻기
print(len(animals), "종류의 동물이 리스트에 있습니다.")
# 아이템 추가하기
animals.append("여우")
# 지금 요소의 개수 묻기
print(len(animals), "종류의 동물이 리스트에 있습니다.")
