# animals 리스트
animals = ["개", "개미", "고양이", "박쥐", "장어"]

# 리스트 루프
for animal in animals:
    # 루프를 반복할 때마다 하나씩 출력하기
    print(animal)
