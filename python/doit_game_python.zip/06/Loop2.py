# 1부터 10까지 루프
for i in range(1, 11):
    # 루프를 반복할 때마다 i 출력하기
    print(i)