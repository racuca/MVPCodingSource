# 리스트 만들기
animals = ["개", "개미", "고양이", "박쥐", "장어"]
# 리스트 출력하기
print(animals)
# 요소 2 바꾸기
animals[2] = "암소"
# 리스트 출력하기
print(animals)
