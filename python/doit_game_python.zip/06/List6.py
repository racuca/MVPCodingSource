# 리스트 만들기
animals = ["이구아나", "개", "박쥐", "장어", "염소", "개미", "고양이"]
# 리스트 출력하기
print(animals)
# 리스트 정렬하기
animals.sort()
# 리스트 출력하기
print(animals)