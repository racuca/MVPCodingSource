name = "Ben"
name = name
print(name)
