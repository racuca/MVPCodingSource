# 라이브러리 불러오기
import random

# 주사위 던지고 출력하기
print("나온 눈:", random.randrange(1, 7))
