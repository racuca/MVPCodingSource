import random

num = random.randrange(1, 11)
print("무작위 숫자:", num)