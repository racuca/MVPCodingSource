# 라이브러리 불러오기
import random

# 주사위 굴리기
die = random.randrange(1, 13)
 
# 십이면체 주사위 값 출력하기
print("나온 눈은 ", die, "입니다!")