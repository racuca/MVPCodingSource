pet = {
    "animal": "Iguana",
    "name": "Iggy",
    "food": "Veggies",
    "mealsPerDay": 1
}

pet["mealsPerDay"] = 2

print(pet["name"], "eats", pet["mealsPerDay"], "meals")
