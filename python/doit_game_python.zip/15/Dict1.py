pet = {
    "animal": "Iguana",
    "name": "Iggy",
    "food": "Veggies",
    "mealsPerDay": 1
}
print(len(pet))