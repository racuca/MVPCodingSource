# 숫자 2개를 곱하고 출력하는 함수
def multiply(n1, n2):
    print(n1, "x", n2, "=", n1 * n2)

# 함수 테스트하기
multiply(12, 8)