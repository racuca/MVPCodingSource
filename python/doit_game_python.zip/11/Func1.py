def sayHello():
    print("Hello")

sayHello()