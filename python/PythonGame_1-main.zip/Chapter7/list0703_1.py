import tkinter
root = tkinter.Tk()
root.title("체크 버튼 다루기")
root.geometry("400x200")
cbtn = tkinter.Checkbutton(text="체크 버튼")
cbtn.pack()
root.mainloop()
