ALP = ["A", "B", "C", "D", "E", "F", "G"]
for i in ALP:
    print(i)
