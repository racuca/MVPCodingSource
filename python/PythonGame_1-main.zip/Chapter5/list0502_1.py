print("유경자 씨의 남편의 이름은?")
ans = input()
if ans == "정현철":
    print("정답입니다")
else:
    print("틀렸습니다")
