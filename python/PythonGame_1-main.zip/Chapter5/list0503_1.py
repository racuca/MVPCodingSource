pl_pos = 6
def board():
    print("•" * (pl_pos - 1) + "Ｐ" + "•" * (30 - pl_pos))

board()
