import random

srp = random.choice(["가위", "바위", "보"])
print(srp)
