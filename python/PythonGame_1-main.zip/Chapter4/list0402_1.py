import calendar

print(calendar.month(2020, 2))
