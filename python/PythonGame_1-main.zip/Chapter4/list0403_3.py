import datetime

d = datetime.datetime.now()
print(d.hour)
print(d.minute)
print(d.second)
