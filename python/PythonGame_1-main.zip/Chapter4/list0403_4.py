import datetime

today = datetime.date.today()
birth = datetime.date(1971, 2, 2)
print(today - birth)
