import calendar

print(calendar.isleap(2020))
