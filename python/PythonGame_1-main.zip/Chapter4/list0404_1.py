import random

r = random.random()
print(r)
