num1 = "1000"
print(num1 + num1)
num2 = int(num1)
print(num2 + num2)
