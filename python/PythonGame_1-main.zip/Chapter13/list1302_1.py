class GameCharacter:
    def __init__(self, job, life):
        self.job = job
        self.life = life
