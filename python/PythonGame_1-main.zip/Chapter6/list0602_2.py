import tkinter
import tkinter.font
root = tkinter.Tk()
print(tkinter.font.families())
