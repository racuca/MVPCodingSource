import tkinter
root = tkinter.Tk()
root.title("첫 번째 윈도우")
root.geometry("800x600")
root.mainloop()
