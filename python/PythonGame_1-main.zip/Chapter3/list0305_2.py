def recover(val):
    print("당신의 체력은 ")
    print(val)
    print("회복했다！")

recover(100)
