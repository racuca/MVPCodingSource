score = 0
print(score)
score = score + 100
print(score)
