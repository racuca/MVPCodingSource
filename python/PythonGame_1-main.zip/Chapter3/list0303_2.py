gold = 100
if gold == 0:
    print("소지금이 없습니다")
else:
    print("구입을 계속하시겠습니까?")
