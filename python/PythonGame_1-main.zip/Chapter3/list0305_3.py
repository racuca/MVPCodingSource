def add(a, b):
    return a + b

c = add(1, 2)
print(c)
