enemy = ["슬라임", "해골 병사", "마법사"]
print(enemy[0])
print(enemy[1])
print(enemy[2])
