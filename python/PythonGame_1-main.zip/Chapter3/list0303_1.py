life = 0
if life <= 0:
    print("게임 오버입니다")
if life > 0:
    print("게임을 계속합니다")
