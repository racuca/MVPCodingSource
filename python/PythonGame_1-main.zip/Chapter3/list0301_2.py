job = "초보 검사"
print("당신의 직업은 " + job)
print("클래스를 변경했다！")
job = "신출내기 용사"
print("새로운 직업은 " + job)
