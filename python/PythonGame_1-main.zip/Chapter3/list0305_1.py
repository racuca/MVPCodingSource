def win():
    print("당신이 승리했습니다!")


win()
